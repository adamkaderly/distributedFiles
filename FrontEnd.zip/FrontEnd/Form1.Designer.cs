﻿namespace FrontEnd
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.FileInsert_btn = new System.Windows.Forms.Button();
            this.SortOptions_box = new System.Windows.Forms.ComboBox();
            this.Submit_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(189, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(436, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "Distributed File Sorting";
            // 
            // FileInsert_btn
            // 
            this.FileInsert_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.FileInsert_btn.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FileInsert_btn.Location = new System.Drawing.Point(215, 140);
            this.FileInsert_btn.Name = "FileInsert_btn";
            this.FileInsert_btn.Size = new System.Drawing.Size(121, 26);
            this.FileInsert_btn.TabIndex = 1;
            this.FileInsert_btn.Text = "Upload File";
            this.FileInsert_btn.UseVisualStyleBackColor = false;
            this.FileInsert_btn.Click += new System.EventHandler(this.FileInsert_btn_Click);
            // 
            // SortOptions_box
            // 
            this.SortOptions_box.Font = new System.Drawing.Font("Bahnschrift", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SortOptions_box.FormattingEnabled = true;
            this.SortOptions_box.Items.AddRange(new object[] {
            "Bubble Sort",
            "Insertion Sort",
            "Merge Sort"});
            this.SortOptions_box.Location = new System.Drawing.Point(377, 142);
            this.SortOptions_box.Name = "SortOptions_box";
            this.SortOptions_box.Size = new System.Drawing.Size(226, 24);
            this.SortOptions_box.TabIndex = 2;
            // 
            // Submit_btn
            // 
            this.Submit_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Submit_btn.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submit_btn.Location = new System.Drawing.Point(295, 201);
            this.Submit_btn.Name = "Submit_btn";
            this.Submit_btn.Size = new System.Drawing.Size(141, 45);
            this.Submit_btn.TabIndex = 3;
            this.Submit_btn.Text = "Submit";
            this.Submit_btn.UseVisualStyleBackColor = false;
            this.Submit_btn.Click += new System.EventHandler(this.Submit_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(778, 438);
            this.Controls.Add(this.Submit_btn);
            this.Controls.Add(this.SortOptions_box);
            this.Controls.Add(this.FileInsert_btn);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Sorting";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button FileInsert_btn;
        private System.Windows.Forms.ComboBox SortOptions_box;
        private System.Windows.Forms.Button Submit_btn;
    }
}

