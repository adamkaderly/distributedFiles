﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrontEnd
{
    public partial class Form1 : Form
    {
        //will need output file to create log.txt file
        private StreamReader inputFile;
        public Form1()
        {
            InitializeComponent();
        }

        private void FileInsert_btn_Click(object sender, EventArgs e)
        {
            try
            {
                String filename = "";
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.ShowDialog();
                filename = ofd.FileName;
                if (File.Exists(filename))
                {
                    inputFile = new StreamReader(filename);
                }
                else
                {
                    MessageBox.Show("File does not exist! Please select another file");
                }
                
            }
            catch(IOException ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Submit_btn_Click(object sender, EventArgs e)
        {
             String line = inputFile.ReadLine();
             while (line != null)
            {
                //code to pass input to utility containers here
                string sort = SortOptions_box.ToString();
                line = inputFile.ReadLine();
            }
           
            inputFile.Close();
        }
    }
}
